/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.*;
import java.sql.PreparedStatement;
import util.DatabaseConnector;
import java.util.ArrayList;
/**
 *
 * @name pc
 */
public class  Customer{
    private String name, address, email; 
    private int phone; 
    private static Connection conn; 
    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getaddress() {
        return address;
    }

    public void setaddress(String address) {
        this.address = address;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }

    public int getphone() {
        return phone;
    }

    public void setphone(int phone) {
        this.phone = phone;
    }

    public Customer(String name, String address, String email, int phone) {
        this.name = name;
        this.address = address;
        this.email = email;
        this.phone = phone;
    }

  public void addToList(){
      try{
          // connect to database
          conn = DatabaseConnector.getConnection();
          String query = "insert into Customer values(?,?,?,?)";
      PreparedStatement stmt = conn.prepareStatement(query);
     stmt.setString(1,name); 
      stmt.setString(2,address); 
      stmt.setString(3,email); 
      stmt.setInt(4,phone); 
      stmt.executeUpdate();
      }catch(SQLException e){
          System.out.println(e.getMessage());
      } finally{
          DatabaseConnector.closeConnection();
      }
  }
    
    public static ArrayList<Customer> listCustomers(){
        
        ArrayList<Customer> list = new ArrayList<>();
        
        try{
        conn = DatabaseConnector.getConnection();
    //query 
String query = "Select * FROM Customer";
Statement stmt = conn.createStatement();
ResultSet rs= stmt.executeQuery(query);
// while there are resultsm create a new object with that information, add that object to our list
while(rs.next()){
    String name = rs.getString("name");
        String address = rs.getString("address");
    String email = rs.getString("email");
int phone = rs.getInt("phone");
Customer b = new Customer(name,address,email,phone); 
    list.add(b);
    
}
    }
    
    catch (SQLException e){
        System.out.println(e.getMessage());
        }   
finally{
        DatabaseConnector.closeConnection();
        }
return list;
    }
}
